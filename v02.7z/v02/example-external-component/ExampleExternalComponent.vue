<template>
  <div>Example external component content</div>
</template>
