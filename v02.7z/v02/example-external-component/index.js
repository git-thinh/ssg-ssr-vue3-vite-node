import ExampleExternalComponent from './ExampleExternalComponent.vue'

export default ExampleExternalComponent
