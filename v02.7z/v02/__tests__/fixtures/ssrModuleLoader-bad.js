export const bad = 1
throw new Error('it is an expected error')
