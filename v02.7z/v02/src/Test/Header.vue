<template>
	<router-link to="/">Home</router-link> |
	<router-link to="/Store">Store</router-link> |
	<router-link to="/External">External</router-link> |
	<router-link to="/about">About</router-link>
</template>
