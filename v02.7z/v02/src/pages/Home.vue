<template>
  <h1>Test</h1>
  <hr>
  <Runtime :name="'rtTest'" />
  <hr>
  <component v-for="c in coms" :is="c"></component>
</template>

<script setup>
  import {
    defineAsyncComponent
  } from 'vue'
  import Runtime from '../components/runtime'

  function load(file) {
    return defineAsyncComponent(() => import(`../Test/${file}.vue`))
  }
  const coms = [load('Header'), load('Test01'), load('Test02')];
</script>

<style scoped>
  h1,
  a {
    color: green;
  }
</style>
