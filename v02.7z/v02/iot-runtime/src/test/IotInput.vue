<template>
	<input type="text" placeholder="search..."/>
</template>

<script>
</script>

<style scoped>
	input{
		border: 1px solid #ccc;
		padding: 3px 7px;
	}
</style>