<template>
	<h1>IotMenuBoxSearch</h1>
</template>

<script>
</script>

<style>
</style>