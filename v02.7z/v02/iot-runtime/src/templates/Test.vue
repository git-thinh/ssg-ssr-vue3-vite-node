<template>
	<h2>This is Test Runtime</h2>
</template>

<script>
	export default {
    name: 'Test'
	}
</script>

<style>
</style>
